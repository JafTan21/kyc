<x-app-layout>
    <x-slot name="header">
        {{ __('About us') }}
    </x-slot>

    <div class="p-4 bg-white rounded-lg shadow-xs">
        {{ __('Sample static text page') }}
    </div>
</x-app-layout>
